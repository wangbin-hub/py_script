#!/bin/bash

# Elasticsearch 主机和端口
ES_HOST="http://localhost:9200"  # 替换为你的 Elasticsearch 地址
ES_USER="elastic"
ES_PASS="UOdYKu*0352Xw#Uq"

# 获取当前日期和 3 天前的日期
FIVE_DAYS_AGO=$(date -d "-4 days" +"%Y.%m.%d")  # 根据你的索引命名约定调整格式


# 获取所有索引的列表
indices=$(curl -s -u $ES_USER:$ES_PASS -X GET "$ES_HOST/_cat/indices?h=index" | tr '\n' ' ')

# 遍历索引并删除 3 天前的索引

for index in $indices; do
    if [[ $index == *"$FIVE_DAYS_AGO"* ]]; then
        echo "Deleting index: $index" >> /tmp/del_index.tmp
        curl -s -u $ES_USER:$ES_PASS -X DELETE "$ES_HOST/$index"
    fi
done

echo "Index deletion completed."

